<?php

$nomClasse = "Niveau";
$nomTable = "niveau";
$identifiant_table = "niveau_id";

$tableau = array(
	'niveau_id' => 'id',
	'niveau_nom' => 'nom'
);

include('../create.php');

?>