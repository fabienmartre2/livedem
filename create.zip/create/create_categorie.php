<?php

$nomClasse = "Categorie";
$nomTable = "categorie";
$identifiant_table = "categorie_id";

$tableau = array(
	'categorie_id' => 'id',
	'categorie_nom' => 'nom'
);

include('../create.php');

?>