<?php

$nomClasse = "Region";
$nomTable = "region";
$identifiant_table = "region_id";

$tableau = array(
	'region_id' => 'id',
	'region_nom' => 'nom',
	'region_fichier' => 'fichier'
);

include('../create.php');

?>