<div id="localisation"> > Accueil Administration</div>
<div id="contenu">

Interface d'administration de <?php echo MARQUE; ?><br /><br />
<u>Version</u> : 1.0<br /><br />


</div>