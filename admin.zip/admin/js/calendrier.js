
$(document).ready(function () {

	$('.datepicker').datepicker({	
		dateFormat : "yy-mm-dd"
	});

	$('.datetimepicker').datepicker({	
		dateFormat : "yy-mm-dd 00:00:00"
	});
	
});
