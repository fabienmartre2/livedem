<?php
Class Annexe extends Annexe_Base { 

}
?>