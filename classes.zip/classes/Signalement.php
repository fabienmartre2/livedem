<?php
Class Signalement extends Signalement_Base { 

}
?>