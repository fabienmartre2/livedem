<?php
Class Ville extends Ville_Base { 

}
?>