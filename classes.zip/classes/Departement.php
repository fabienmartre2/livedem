<?php
Class Departement extends Departement_Base { 

}
?>