<?php
Class BlocMail extends BlocMail_Base { 

}
?>