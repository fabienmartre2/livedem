<?php
Class PropositionModif extends PropositionModif_Base { 

}
?>