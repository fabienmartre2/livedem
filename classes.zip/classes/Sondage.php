<?php
Class Sondage extends Sondage_Base { 

}
?>