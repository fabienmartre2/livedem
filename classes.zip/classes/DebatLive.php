<?php
Class DebatLive extends DebatLive_Base { 

}
?>