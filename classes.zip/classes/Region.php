<?php
Class Region extends Region_Base { 

}
?>