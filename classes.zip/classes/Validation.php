<?php
Class Validation extends Validation_Base { 

}
?>