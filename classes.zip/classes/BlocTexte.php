<?php
Class BlocTexte extends BlocTexte_Base { 

}
?>