<?php
Class VoteSondage extends VoteSondage_Base { 

}
?>